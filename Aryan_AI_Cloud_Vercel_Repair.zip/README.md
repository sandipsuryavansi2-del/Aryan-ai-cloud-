# Aryan AI Cloud — Vercel Repair ZIP

This version avoids the blank-screen cause in the previous `index.html`: it is a complete standalone HTML app and does **not** reference the missing `/src/main.jsx`.

## Files to upload to the GitHub repository root

Keep this exact structure:

```text
Aryan-ai-cloud/
├── index.html
├── package.json
├── vercel.json
├── README.md
└── api/
    └── chat.js
```

Upload all files and the `api` folder to the **root** of the same GitHub repository connected to Vercel. Do not upload only `index.html`.

## Configure AI in Vercel

1. Open Vercel Dashboard → `aryan-ai-cloud` → **Settings** → **Environment Variables**.
2. Add:
   - `AI_PROVIDER` = `groq`
   - `AI_API_KEY` = your provider API key (keep it secret; do not put it in GitHub or HTML)
   - `AI_MODEL` = `llama-3.3-70b-versatile` (use a model currently available to your provider account)
3. Apply to **Production** (and Preview if you use it), save.
4. Go to **Deployments** and redeploy the latest deployment so the new files and variables are used.

The AI provider may require an account and may have usage limits or charges. This ZIP does not promise unlimited or always-free AI.

## Test in this order

1. Open `https://YOUR-PROJECT.vercel.app/` — the Aryan AI Cloud interface should appear.
2. Open `https://YOUR-PROJECT.vercel.app/api/chat` — should return JSON showing endpoint status and whether the key is configured.
3. Send a chat message from the website. If it fails, open Vercel → Deployments → latest deployment → Functions/Logs and read the error.

## Important limitations

- The AI chat and Developer helper use the server-side `/api/chat` function.
- Study summarization works after you paste text; this starter does not bundle PDF text extraction.
- Storage is a local file-list demo, not cloud upload/sync. Supabase storage/auth must be configured separately before using real accounts or private cloud files.
- Status page is diagnostic only, not a secure admin panel.
- Never commit `.env`, API keys, Supabase service-role keys, or admin passwords to GitHub.
